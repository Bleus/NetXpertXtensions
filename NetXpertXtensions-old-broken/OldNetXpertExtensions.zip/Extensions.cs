﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace NetXpertExtensions
{
	public static partial class MiscellaneousExtensions
	{
		/// <summary><?xml version='1.0' encoding='UTF-8' standalone='yes' ?> + CRLF</summary>
		public static readonly string XML_HEADER = "<?xml version='1.0' encoding='UTF-8' standalone='yes' ?>\r\n";

		/// <summary>Provides a means to extract all column names from a row (handy for iterative processing of columns).</summary>
		/// <returns>An array containing all of the column names in the row.</returns>
		public static string[] GetNames( this DataGridViewCellCollection cells )
		{
			List<string> colNames = new List<string>();
			foreach ( DataGridViewCell cell in cells )
				colNames.Add( cell.OwningColumn.Name );

			return colNames.ToArray();
		}

		/// <summary>Takes a ulong value and converts it to a string representation.</summary>
		/// <param name="fileSize">A ulong value to parse.</param>
		/// <param name="useLongSuffix">Optional parameter that, if set to TRUE will cause the file size units to be full words, instead of abbreviations.</param>
		/// <returns>The supplied value, parsed into a string.</returns>
		public static string FileSizeToString( this ulong fileSize, bool useLongSuffix = false )
		{
			Decimal Divide( ulong a, byte p ) => Decimal.Divide( (Decimal)a, (Decimal)Math.Pow( 2, p ) );

			string[] sfx =
				useLongSuffix ?
					new string[] { " bytes", " kilobytes", " megabytes", " gigabytes" } :
					new string[] { " B", " KB", " MB", " GB" };
			//sfx[0] = " bytes";

			// 100GB+: Report as Gigabytes with no decimals.
			if ( fileSize >= 0x1900000000 )
				return Divide( fileSize, 30 ).ToString( "N0" ) + sfx[ 3 ]; // 2^30 = 1,073,741,824 = 0x40000000

			// 10GB+: Report as Gigabytes with one decimal.
			if ( fileSize >= 0x280000000 )
				return Divide( fileSize, 30 ).ToString( "N1" ) + sfx[ 3 ]; // 2^30 = 1,073,741,824 = 0x40000000

			// 2GB+ : Report as Gigabytes with two decimals.
			if ( fileSize >= 0x80000000 )
				return Divide( fileSize, 30 ).ToString( "N2" ) + sfx[ 3 ]; // 2^30 = 1,073,741,824 = 0x40000000

			// Over 1GB: Report as Megabytes with no decimals.
			if ( fileSize > 0x40000000 )
				return Math.Round( Divide( fileSize, 20 ) ).ToString( "N0" ) + sfx[ 2 ]; // 2^20 = 1,048,576 = 0x100000

			// 100MB+: Report as Megabytes with one decimal.
			if ( fileSize > 0x6400000 )
				return Divide( fileSize, 20 ).ToString( "N1" ) + sfx[ 2 ]; // 2^20 = 1,048,576 = 0x100000

			// Over 2MB: Report as Megabytes with two decimals.
			if ( fileSize > 0x200000 )
				return Divide( fileSize, 20 ).ToString( "N2" ) + sfx[ 2 ]; // 2^20 = 1,048,576 = 0x100000

			// Over 1MB: Report as Kilobytes with no decimals.
			if ( fileSize > 0x100000 )
				return Math.Round( Divide( fileSize, 10 ) ).ToString( "N0" ) + sfx[ 1 ]; // 2^10 = 1024 = 0x400

			// Over 100kb: Report as Kilobytes with one decimal.
			if ( fileSize > 0x19000 )
				return Divide( fileSize, 10 ).ToString( "N1" ) + sfx[ 1 ]; // 2^10 = 1024 = 0x400

			// Over 2kb: Report as Kilobytes with two decimals.
			if ( fileSize > 0x800 )
				return Divide( fileSize, 10 ).ToString( "N2" ) + sfx[ 1 ]; // 2^10 = 1024 = 0x400

			return fileSize.ToString() + sfx[ 0 ];
		}

		public static string FileSizeToString( this long fileSize, bool useLongSuffix = false ) =>
			((ulong)Math.Abs( fileSize )).FileSizeToString( useLongSuffix );

		public static string FileSizeToString( this int fileSize, bool useLongSuffix = false ) =>
			((ulong)Math.Abs( fileSize )).FileSizeToString( useLongSuffix );

		public static string FileSizeToString( this uint fileSize, bool useLongSuffix = false ) =>
			((ulong)fileSize).FileSizeToString( useLongSuffix );

		/// <summary>Extends the TimeSpan Class to add parsing into a variable-length string showing only the relevant information.</summary>
		/// <param name="showMs">If set to TRUE, causes the milliseconds value to be shown, otherwise it is ignored (Default: FALSE)</param>
		/// <param name="useLongWords">If set to TRUE, uses the full words for the result, otherwise just uses abbreviations.</param>
		/// <returns>A string showing the TimeSpan value broken out into days/hours/minutes/seconds/milliseconds as appropriate.</returns>
		public static string ToLongString( this TimeSpan value, bool showMs = false, bool useLongWords = false )
		{
			string[] sfx = useLongWords ? new string[] { " days", " hours", " minutes", " seconds", " milliseconds" } : new string[] { "d", "h", "m", "s", "ms" };
			string result = "";
			if ( value.TotalHours > 24 )
				result += value.Days.ToString() + sfx[ 0 ];

			if ( value.Hours > 0 )
				result += ((result.Length > 0) ? " " : "") + value.Hours.ToString() + sfx[ 1 ];

			if ( value.Minutes > 0 )
				result += ((result.Length > 0) ? " " : "") + value.Minutes.ToString() + sfx[ 2 ];

			if ( value.Seconds > 0 )
				result += ((result.Length > 0) ? " " : "") + value.Seconds.ToString() + sfx[ 3 ];

			if ( showMs && (value.Milliseconds > 0) )
				result += ((result.Length > 0) ? " " : "") + value.Hours.ToString() + sfx[ 4 ];

			return result;
		}

		/// <summary>Takes a TimeSpan and presents its "total" value in an accurate and succinct way.</summary>
		public static string TotalToString( this TimeSpan value )
		{
			//if (value.TotalMilliseconds < 10)
			//	return value.TotalMilliseconds.ToString( "N2" ) + " ms";

			//if (value.TotalMilliseconds < 100)
			//	return value.TotalMilliseconds.ToString( "N1" ) + " ms";

			if ( value.TotalMilliseconds < 1000 )
				return value.TotalMilliseconds.ToString( "N0" ) + " ms";

			if ( value.TotalSeconds < 10 )
				return value.TotalSeconds.ToString( "N1" ) + " s";

			if ( value.TotalSeconds < 60 )
				return value.TotalSeconds.ToString( "N1" ) + " s";

			if ( value.TotalSeconds < 150 )
				return value.TotalSeconds.ToString( "N0" ) + " s";

			if ( value.TotalMinutes < 15 )
				return value.TotalMinutes.ToString( "N0" ).PadLeft( 3, ' ' ) + "m " +
					Math.Truncate( value.TotalSeconds % 60 ).ToString( "N1" ).PadLeft( 4, '0' ) + " s";

			if ( value.TotalMinutes < 60 )
				return value.TotalMinutes.ToString( "N0" ).PadLeft( 3, ' ' ) + "m " +
					Math.Truncate( value.TotalSeconds % 60 ).ToString( "N0" ).PadLeft( 2, '0' ) + " s";

			if ( value.TotalMinutes < 180 )
				return value.TotalMinutes.ToString( "N0" ).PadLeft( 3, ' ' ) + "m";

			return value.TotalHours.ToString( "N0" ) + "h " +
				(value.TotalMinutes % 60).ToString( "N0" ) + "m";
		}

		/// <summary>Facilitates quick and easy access to the EntryAssembly's Version information.</summary>
		/// <returns>The EntryAssembly's Version information.</returns>
		public static Version AssemblyVersion() => Assembly.GetEntryAssembly().GetName().Version;

		/// <summary>Adds a function to dereference just the base name portion of an Assembly from the FullName.</summary>
		/// <returns>The extracted base name if able, otherwise just the FullName.</returns>
		public static string ExtractName( this Assembly root )
		{
			string pattern = /* language=regex */ @"^(?<assy>(?:[a-zA-Z\d]+[.]?)+)(?>,).*$", work = root.FullName;
			MatchCollection matches = Regex.Matches( work, pattern, RegexOptions.IgnoreCase | RegexOptions.ExplicitCapture );
			if ( matches.Count > 0 )
				return matches[ 0 ].Groups[ "assy" ].Value;

			if ( work.IndexOf( "," ) > 3 )
				return work.Substring( 0, work.IndexOf( ',' ) );

			return root.FullName;
		}

		/// <summary>Extends the Object class to add the ability to test any object's ancestry.</summary>
		/// <typeparam name="T">The ancestor class to verify.</typeparam>
		/// <param name="type">The local object class</param>
		/// <returns>TRUE if the calling object's class has Typeof[T] as an ancestor class.</returns>
		public static bool IsDerivedFrom<T>( this object obj ) => IsDerivedFrom<T>( obj.GetType() );

		/// <summary>Extends the Type class to add an ability to test the Class ancestry of the calling Type.</summary>
		/// <typeparam name="T">The ancestor class to look for.</typeparam>
		/// <returns>TRUE if the specified Class is an ancestor of the calling Type.</returns>
		public static bool HasAncestor<T>( this Type type ) => IsDerivedFrom<T>( type );

		/// <summary>Working portion of Object.IsDerivedFrom[T]() and Type.HasAncestor[T]() extension methods.</summary>
		private static bool IsDerivedFrom<T>( Type t ) => typeof( T ) == t ||
			((t.BaseType == typeof( Object )) ? typeof( T ) == typeof( Object ) : (t.BaseType == typeof( T ) ? true : IsDerivedFrom<T>( t.BaseType )));

		/// <summary>Faciltiates loading a text file from the specified EntryAssembly's Resources.</summary>
		/// <param name="name">The full name of the resource to retrieve (i.e. ApplicationNamespace.folderName.FileName.xml)</param>
		/// <returns>The requested file in a string.</returns>
		public static string FetchInternalResourceFile( string name )
		{
			var assembly = Assembly.GetEntryAssembly();
			using ( Stream stream = assembly.GetManifestResourceStream( name ) )
			using ( StreamReader reader = new( stream ) )
				return reader.ReadToEnd();
		}

		/// <summary>Faciltiates loading a binary file from the specified EntryAssembly's Resources.</summary>
		/// <param name="name">The full name of the resource to retrieve (i.e. ApplicationNamespace.folderName.FileName.bin)</param>
		/// <returns>The contents of the requested file in a byte array.</returns>
		public static byte[] FetchInternalBinaryResourceFile( string name )
		{
			var assembly = Assembly.GetEntryAssembly();
			try
			{
				using ( Stream stream = assembly.GetManifestResourceStream( name ) )
				using ( MemoryStream reader = new() )
				{
					stream.CopyTo( reader );
					return reader.ToArray();
				}
			}
			catch ( Exception inner )
			{
				throw new FileNotFoundException( $"The requested resource (\"{name}\") was not found.", inner );
			}
		}

		/// <summary>Searches all loaded assemblies in a project for the specified embedded resource text file.</summary>
		/// <returns>If the specified resource is found, its contents as a string, otherwise throws a DllNotFoundException.</returns>
		/// <exception cref="DllNotFoundException"></exception>
		public static byte[] FetchAssemblyBinaryResourceFile( string name )
		{
			Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
			int i = -1; while ( (++i < assemblies.Length) && !Regex.IsMatch( name, $"^({assemblies[ i ].ExtractName()})", RegexOptions.IgnoreCase ) ) ;
			if ( i < assemblies.Length )
			{
				try
				{
					using ( Stream stream = assemblies[ i ].GetManifestResourceStream( name ) )
					using ( MemoryStream reader = new() )
					{
						stream.CopyTo( reader );
						return reader.ToArray();
					}
				}
				catch ( Exception inner )
				{
					throw new FileNotFoundException( $"The requested resource (\"{name}\") was not found.", inner );
				}
			}
			throw new DllNotFoundException( $"The requested assembly resource (\"{name}\") could not be found." );
		}

		/// <summary>Searches all loaded assemblies in a project for the specified embedded resource text file.</summary>
		/// <returns>If the specified resource is found, its contents as a string, otherwise throws a DllNotFoundException.</returns>
		/// <exception cref="DllNotFoundException"></exception>
		public static string FetchAssemblyResourceFile( string name )
		{
			Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
			int i = -1; while ( (++i < assemblies.Length) && !Regex.IsMatch( name, $"^({assemblies[ i ].ExtractName()})", RegexOptions.IgnoreCase ) ) ;
			if ( i < assemblies.Length )
			{
				try
				{
					using ( Stream stream = assemblies[ i ].GetManifestResourceStream( name ) )
					using ( StreamReader reader = new( stream, true ) )
						return reader.ReadToEnd();
				}
				catch ( Exception inner )
				{
					throw new FileNotFoundException( $"The requested resource (\"{name}\") was not found.", inner );
				}
			}
			throw new DllNotFoundException( $"The requested assembly resource (\"{name}\") could not be found." );
		}


		/// <summary>Searches all loaded assemblies in a project for the specified embedded resource text file.</summary>
		/// <param name="encoding">What <seealso cref="System.Text.Encoding"/> mechanism should be used when loading the file.</param>
		/// <returns>If the specified resource is found, its contents as a string, otherwise throws a DllNotFoundException.</returns>
		/// <remarks></remarks>
		/// <exception cref="DllNotFoundException"></exception>
		public static string FetchAssemblyResourceFile( string name, System.Text.Encoding encoding )
		{
			Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
			int i = -1; while ( (++i < assemblies.Length) && !Regex.IsMatch( name, $"^({assemblies[ i ].ExtractName()})", RegexOptions.IgnoreCase ) ) ;
			if ( i < assemblies.Length )
			{
				try {
					using ( Stream stream = assemblies[ i ].GetManifestResourceStream( name ) )
					using ( StreamReader reader = new( stream, encoding ) )
						return reader.ReadToEnd();
				}
				catch ( Exception inner )
				{
					Exception result = new Exception( $"The requested resource (\"{name}\") was not found.", inner );
					throw result;
				}
			}
			throw new DllNotFoundException( $"The requested assembly resource (\"{name}\") could not be found." );
		}

		// "CobblestoneCommon.XmlFormating.xsl"
		//public static string FetchDllResourceFile(string name)
		//{
		//	string[] parts = name.Split(new char[] { '.' }, 2);
		//	if (parts.Length == 2)
		//	{
		//		Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
		//		int i = -1; while ((++i < assemblies.Length) && !Regex.IsMatch(assemblies[i].FullName, @"^" + parts[0] + @", .*$", RegexOptions.IgnoreCase) );
		//		if (i < assemblies.Length)
		//		{
		//			using (System.IO.Stream stream = assemblies[i].GetManifestResourceStream(name))
		//			using (System.IO.StreamReader reader = new System.IO.StreamReader(stream))
		//				return reader.ReadToEnd();
		//		}
		//		throw new DllNotFoundException("The requested DLL (\"" + parts[0] + "\") could not be found in the loaded Assemblies.");
		//	}
		//	throw new ArgumentException("The provided item name (\"" + name + "\") is not in properly dotted notation.");
		//}

		/// <summary>Returns the path to the current executable file.</summary>
		public static string LocalExecutablePath
		{
			get
			{
				string data = Assembly.GetEntryAssembly().GetName().CodeBase;
				data = data.Substring( data.IndexOf( "///" ) + 3 ); // Get rid of https: file: etc headers...

				data = Path.GetDirectoryName( data );
				if ( !data.EndsWith( Path.DirectorySeparatorChar.ToString(), StringComparison.Ordinal ) )
					data += Path.DirectorySeparatorChar;

				return data;
			}
		}

		public static string ExecutableName => System.Diagnostics.Process.GetCurrentProcess().ProcessName;

		/// <summary>Provides a mechanism to quickly and easily fill an array with a specified value.</summary>
		/// <param name="value">The value to fill the array with.</param>
		/// <param name="size">The size of the array to return.</param>
		/// <param name="preserveContents">If set to TRUE, any existing contents of the original array are retained, otherwise they're overwritten.</param>
		/// <returns>An array of the specified type and length whose values have been set to the specified value.</returns>
		public static T[] Fill<T>( this T[] source, T value = default, int size = -1, bool preserveContents = false )
		{
			List<T> result = new List<T>();
			if ( size < 1 ) size = source.Length;
			if ( size > 0 )
			{
				if ( preserveContents ) result.AddRange( source );
				while ( result.Count < size ) result.Add( value );
			}
			while ( result.Count > size ) result.RemoveAt( result.Count - 1 );

			return result.ToArray();
		}

		/// <summary>Returns a new array consisting of the source array shortened to the specified "size".</summary>
		/// <param name="size">The maximum length of the returned array. If the source is shorter than this, the entire array is returned.</param>
		/// <returns>An array of maximum length "size" containing as many entries as will fit from the source array.</returns>
		/// <remarks>The resulting array WILL be shorter in length than "size" if there are insufficient records in the source array!</remarks>
		public static T[] Truncate<T>( this T[] source, int size ) =>
			size >= source.Length ? source : new List<T>( source ).ToArray( size );

		/// <summary>Copies a specified section out of an array into a new array.</summary>
		/// <param name="start">The index to start copying from.</param>
		/// <param name="end">The index to finish copying at.</param>
		/// <returns>An array containing all of the records from the source within the specified scope.</returns>
		/// <remarks>If no other values are specified, this function defaults to starting at the beginning, and finishing at the end.</remarks>
		public static T[] Copy<T>( this T[] source, int start = 0, int end = int.MaxValue )
		{
			if ( (start < 1) && (end >= source.Length) )
				return source;

			start = Math.Min( Math.Max( 0, start ), source.Length );
			end = Math.Min( source.Length, Math.Max( start, end ) );

			List<T> results = new List<T>();
			for ( int i = start; i < end; i++ )
				results.Add( source[ i ] );

			return results.ToArray();
		}

		/// <summary>Returns a new Array&lt;T&gt; object containing the elements of the source Array in reverse order.</summary>
		/// <typeparam name="T">The datatype managed by the array.</typeparam>
		public static T[] ReverseOrder<T>( this T[] source )
		{
			if ( (source is null) || (source.Count() == 0) ) return Array.Empty<T>();
			T[] result = new T[ source.Length ];
			if ( source.Count() == 1 )
				result[ 0 ] = source[ 0 ];
			else
			{
				for ( int i = 0; i < source.Length; ) 
					result[ i++ ] = source[ source.Length - i ];
			}
			return result;
		}

		/// <summary>
		/// Adds an option to the "List" collective class to facilitate returning an array of only the first "size" elsments
		/// from the list in the resulting array (rather than all of it).</summary>
		/// <typeparam name="T">The defined generic Type of the List.</typeparam>
		/// <param name="size">How many entries to return. If the size is bigger than the original list, all elements are returned.</param>
		/// <returns>An array of type T containing the lesser of all the items from the source list, or the number specified by "size".</returns>
		/// <remarks><b>NOTE</b>: If the <paramref name="size"/> value is negative, the returned array is taken from the <i>end</i> of <paramref name="source"/> instead.</remarks>
		public static T[] ToArray<T>( this List<T> source, int size )
		{
			if ( size == 0 ) return Array.Empty<T>();
			if ( Math.Abs(size) >= source.Count ) return source.ToArray();

			List<T> result = new();
			if ( size > 0 )
			{
				for ( int i = 0; i < size; ) result.Add( source[ i++ ] );
			}
			else
			{
				for ( int i = 0; i > size; ) result.Add( source[ source.Count - --i ] );
			}
			return result.ToArray();
		}

		/// <summary>
		/// Adds an option to the "List" collective class to facilitate returning an array of only the first "size" elsments
		/// from the list in the resulting array (rather than all of it).</summary>
		/// <typeparam name="T">The defined generic Type of the List.</typeparam>
		/// <param name="size">
		/// How many entries to return. If the size is bigger than the original list, the returned array will be padded with the value
		/// specified in "fill".
		/// </param>
		/// <param name="fillValue">The value to use for excess results if the requested array size is larger than the source list.</param>
		/// <returns>An array of type T, of length "Size" containing the items from the source list and, padded with the "fill" value if required.</returns>
		public static T[] ToArray<T>( this List<T> source, int size, T fillValue) =>
			size > source.Count ? source.ToArray().Fill( fillValue, size, true ) : source.ToArray( size );

		/// <summary>Facilitates encoding a byte[] object into a Base64 encoded string.</summary>
		public static string ToBase64String( this byte[] source )
		{
			if ( (source is null) || (source.Length == 0) ) return "";

			long length = (long)((4.0d / 3.0d) * source.Length);
			char[] result = new char[ (length % 4) > 0 ? 4 - (length % 4) : 0 ];
			Convert.ToBase64CharArray( source, 0, source.Length, result, 0 );
			return new string( result );
		}

		/// <summary>Faciltiates converting a Base64 encoded string into a byte array.</summary>
		public static byte[] FromBase64String( this string source ) =>
			Convert.FromBase64String( source );

		private class GenericComparer<T> : IComparer<T>
		{
			public int Compare( T left, T right ) => left.Equals( right ) ? 0 : 1;
		}

		public static bool Contains<T>( this List<T> source, T value ) => source.ToArray().Contains( value );

		public static bool Contains<T>( this T[] source, T value, IComparer<T> comparer = null)
		{
			if ( comparer is null ) comparer = new GenericComparer<T>();

			int i = -1;
			while ( (++i < source.Length) && (comparer.Compare( source[i], value ) == 0) ) ;

			return i < source.Length;
		}

		/// <summary>Facilitates invoking a control from a separate thread.</summary>
		/// <param name="del">A function delegate to execute against the control..</param>
		/// <seealso cref="https://stackoverflow.com/a/36983936/1542024"/>
		/// <example>controlName.Invoke(t => t.text = "A" );</example>
		/// <remarks></remarks>
		public static void Invoke<TControlType>( this TControlType control, Action<TControlType> del )
				where TControlType : Control
		{
			if ( control.InvokeRequired )
				control.Invoke( new Action( () => del( control ) ) );
			else
				del( control );
		}

		[DllImport( "user32.dll", SetLastError = true )]
		[return: MarshalAs( UnmanagedType.Bool )]
		private static extern bool GetWindowPlacement( IntPtr hWnd, ref WINDOWPLACEMENT lpwndpl );

		private struct WINDOWPLACEMENT
		{
			public int length;
			public int flags;
			public int showCmd;
			public System.Drawing.Point ptMinPosition;
			public System.Drawing.Point ptMaxPosition;
			public System.Drawing.Rectangle rcNormalPosition;
		}

		/// <summary>Correctly restores a minimized window (Form element) to it's proper pre-minimized state.</summary>
		/// <param name="performUnminimize">If set to FALSE, just the proper FormWindowState is returned and no action is taken.</param>
		/// <returns>The un-minimized FormWindowState for the window.</returns>
		public static FormWindowState Unminimize( this Form form, bool performUnminimize = true )
		{
			const int WPF_RESTORETOMAXIMIZED = 0x2;

			FormWindowState result = form.WindowState;
			WINDOWPLACEMENT placement = new WINDOWPLACEMENT();
			placement.length = Marshal.SizeOf( placement );
			GetWindowPlacement( form.Handle, ref placement );

			result =(placement.flags & WPF_RESTORETOMAXIMIZED) == WPF_RESTORETOMAXIMIZED ? FormWindowState.Maximized : FormWindowState.Normal;

			if ( performUnminimize ) form.WindowState = result;

			return result;
		}

		/// <summary>Given a string, endeavours to validate it as a Windows path+filename.</summary>
		/// <param name="fullFilePathandName">The value to validate.</param>
		/// <param name="checkExists">If set to true, also checks to see if the file actually exists.</param>
		/// <returns><b>TRUE</b> if the supplied string meets the specification for a valid Windows path + filename. 
		/// If the optioanl <i>checkExists</i> flag is set, the file must also exist to return <b>true</b>.</returns>
		public static bool ValidateWindowsFilePath( string fullFilePathandName, bool checkExists = false )
		{
			if ( !string.IsNullOrWhiteSpace( fullFilePathandName ) && (fullFilePathandName.IndexOfAny(Path.GetInvalidPathChars()) < 0) )
			{
				// Basic patthen check; will incorrectly validate paths with multiple periods, and rejects paths with '+' signs...
				Match m = Regex.Match( fullFilePathandName, @"^(?<drive>[a-z]:)?(?<path>(?:[\\]?(?:[\w !#()-]+|[.]{1,2})+)*[\\])?(?<filename>(?:[.]?[\w !#()-]+)+)?[.]?$", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant, TimeSpan.FromSeconds(10) );
				if ( m.Success )
				{
					// Though it's technically valid to do so, I prefer to reject filenames with grouped periods...
					if ( m.Groups[ "filename" ].Success && Regex.IsMatch( m.Groups[ "filename" ].Value, @"[.]{2,}" ) ) return false;

					try { return !checkExists || File.Exists( fullFilePathandName ); }
					catch { }
				}
			}
			return false;
		}
	}
}
