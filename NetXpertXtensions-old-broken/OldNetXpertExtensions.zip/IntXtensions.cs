using System;
using System.Collections.Generic;
using System.Numerics;
using System.Security.Cryptography;

namespace NetXpertExtensions
{
	public static partial class NetXpertExtensions
	{
		#region Int extensions
		/// <summary>Returns a pseudo-random number between 0 and the value of the integer that's calling the function.</summary>
		/// <returns>A pseudo-random number between 0 and the value of the integer that's calling the function.</returns>
		public static int Random(this int source)
		{
			var rnd = RandomNumberGenerator.Create();
			byte[] bytes = Array.Empty<byte>();
			rnd.GetBytes( bytes );
			uint value = bytes[0] | (uint)(bytes[1] << 8) | (uint)(bytes[2] << 16) | (uint)(bytes[3] << 24);
			float multiplier = uint.MaxValue / value;
			return (int)Math.Floor( multiplier * source );

			//TimeSpan sinceMidnight = DateTime.Now - DateTime.Today;
			//int seed = (source % 10) * (int)sinceMidnight.TotalMilliseconds;
			//Random random = new(seed);
			//return random.Next(source);
		}

		/// <summary>Generates a pseudo-random number between "source" and "source + maxValue" and returns it.</summary>
		/// <param name="maxValue">The range of random values (above the source) that are desired.</param>
		/// <returns>The random value that was generated.</returns>
		public static int Random(this int source, int maxValue) => source + maxValue.Random();

		/// <summary>Provides a mechanism for quickly determining if a given integer falls within a specified range.</summary>
		/// <param name="top">An integer specifying the top of the range to check.</param>
		/// <param name="bottom">An optional integer specifying the bottom of the range. Defaults to 0 if unspecified.</param>
		/// <param name="includeBoundaries">If TRUE, the test will accept values equal to the upper or lower bounds, otherwise it won't.</param>
		/// <returns>TRUE if the tested value is with the specified range according to the passed parameters.</returns>
		/// <remarks>
		/// The "includeBoundaries" option is a nullable boolean. If NULL is passed here, the InRange check includes the lower bounds
		/// but excludes the upper. This is useful for checks on loop ranges where zero is valid, but the Length/Count value is actually out of range.
		/// </remarks>
		public static bool InRange( this int source, int top, int bottom = 0, bool? includeBoundaries = true )
		{
			// If the call accidently inverts the top/bottom, correct it for them...
			if (top < bottom) { int t = top; top = bottom; bottom = t; }

			// Use to check ranges on loop values where ".Count" or ".Length" values are 1 step beyond the allowable range...
			if ( includeBoundaries is null ) return (source >= bottom) && (source < top);
			
			return (bool)includeBoundaries ?
				(source >= bottom) && (source <= top)
			:
				(source > bottom) && (source < top);
		}

		/// <summary>Provides a mechanism for pluralizing a string from an Int value.</summary>
		/// <param name="sample">A string to pluralize.</param>
		/// <param name="with">What to append to the string if it's plural.</param>
		/// <returns>The "sample" string pluralized.</returns>
		public static string Pluralize( this int source, string sample = "", string with = "s" ) =>
			sample + ((source == 1) ? "" : with);


		/// <summary>Provides a mechanism for pluralizing a string from an Int value.</summary>
		/// <param name="sample">A string to pluralize.</param>
		/// <param name="with">What to append to the string if it's plural.</param>
		/// <returns>The "sample" string pluralized.</returns>
		public static string Pluralize( this decimal source, string sample = "", string with = "s" ) =>
			sample + (source == 0.0m ? "" : with);


		/// <summary>Provides a mechanism for pluralizing a string from an Int value.</summary>
		/// <param name="sample">A string to pluralize.</param>
		/// <param name="with">What to append to the string if it's plural.</param>
		/// <returns>The "sample" string pluralized.</returns>
		public static string Pluralize( this float source, string sample = "", string with = "s" ) =>
			sample + (source == 0.0f ? "" : with);


		/// <summary>Provides a mechanism for pluralizing a string from an Int value.</summary>
		/// <param name="sample">A string to pluralize.</param>
		/// <param name="with">What to append to the string if it's plural.</param>
		/// <returns>The "sample" string pluralized.</returns>
		public static string Pluralize( this double source, string sample = "", string with = "s" ) =>
			sample + (source == 0.0d ? "" : with);

		/// <summary>Tests an integer against a collection of int's and returns the lowest value.</summary>
		/// <param name="startValue">The initial int value to test.</param>
		/// <param name="values">All subsequent int values to test.</param>
		/// <returns>The lowest int value between the calling int, and all of the provided ints.</returns>
		public static int Min( this int source, int startValue, params int[] values )
		{
			startValue = Math.Min( source, startValue );
			if ( (values is null) || (values.Length == 0) ) return startValue;

			foreach ( int i in values )
				if ( i < startValue ) startValue = i;

			return startValue;
		}

		/// <summary>Tests an integer against a collection of int's and returns the highest value.</summary>
		/// <param name="startValue">The initial int value to test.</param>
		/// <param name="values">All subsequent int values to test.</param>
		/// <returns>The highest int value between the calling int, and all of the provided ints.</returns>
		public static int Max(this int source, int startValue, params int[] values)
		{
			startValue = Math.Max( source, startValue );
			if ( (values is null) || (values.Length == 0) ) return startValue;

			foreach ( int i in values )
				if ( i > startValue ) startValue = i;

			return startValue;
		}

		/// <summary>Facilitates creating a range of integers from a starting value to a specified ending one.<br/><b>NOTE:</b>
		/// Using this to iterate arrays is <i>highly</i> inefficient as the computer will have to loop all values twice!
		/// </summary>
		/// <param name="end">The value to interate to. This value <b>will</b> be included in the output!</param>
		/// <remarks>If the 'end' value is <i>lower</i> than the starting value, the resulting array will count <i>down</i>
		/// to the ending value!</remarks>
		/// <returns>An array of integers from (and including) the <i>start</i> value through to (and including) the <i>ending</i> one.</returns>
		public static int[] RangeTo( this int start, int end )
		{
			if ( end == start ) return new int[] { start };

			List<int> values = new List<int>();
			if ( end > start )
				for ( int i = start; i <= end; i++ ) values.Add( i );
			else
				for ( int i = start; i >= end; i-- ) values.Add( i );

			return values.ToArray();
		}

		// Provides a simpler means of integer exponentiation.
		public static sbyte Pow( this sbyte source, int exponent ) => 
			(sbyte)BigInteger.Pow( source, exponent );

		public static byte Pow( this byte source, int exponent ) => 
			(byte)BigInteger.Pow( source, exponent );

		public static short Pow( this short source, int exponent ) => 
			(short)BigInteger.Pow( source, exponent );

		public static ushort Pow( this ushort source, int exponent ) =>
			(ushort)BigInteger.Pow( source, exponent );

		public static int Pow( this int source, int exponent ) =>
			(int)BigInteger.Pow( source, exponent );

		public static uint Pow( this uint source, int exponent ) =>
			(uint)BigInteger.Pow( source, exponent );

		public static long Pow( this long source, int exponent ) =>
			(long)BigInteger.Pow( source, exponent );

		// Provides a mechanism for representing integer types as Binary Strings
		public static string ToBinaryString( this sbyte source, string byteSplit = null, string nibbleSplit = null ) =>
			((long)source).ToBinaryString( byteSplit, nibbleSplit );

		public static string ToBinaryString( this byte source, string byteSplit = null, string nibbleSplit = null ) =>
			((long)source).ToBinaryString( byteSplit, nibbleSplit );

		public static string ToBinaryString( this ushort source, string byteSplit = null, string nibbleSplit = null ) =>
			((long)source).ToBinaryString( byteSplit, nibbleSplit );

		public static string ToBinaryString( this short source, string byteSplit = null, string nibbleSplit = null ) =>
			((long)source).ToBinaryString( byteSplit, nibbleSplit );

		public static string ToBinaryString( this int source, string byteSplit = null, string nibbleSplit = null ) =>
			((long)source).ToBinaryString( byteSplit, nibbleSplit );

		public static string ToBinaryString( this uint source, string byteSplit = null, string nibbleSplit = null ) =>
			((long)source).ToBinaryString( byteSplit, nibbleSplit );

		public static string ToBinaryString( this ulong source, string byteSplit = null, string nibbleSplit = null ) =>
			((long)source).ToBinaryString( byteSplit, nibbleSplit );

		public static string ToBinaryString( this long source, string byteSplit = null, string nibbleSplit = null )
		{
			if ( byteSplit is null ) byteSplit = " ";
			if ( nibbleSplit is null ) nibbleSplit = "";

			string result = "";
			string[] nibbles = Convert.ToString( source, 2 ).PadLeft( 64, '0' ).Split( 4 );

			for ( int i = 0; i < 16; i++ )
				result += ((i > 0) && (i % 2 == 0) ? byteSplit : nibbleSplit) + nibbles[ i ];

			return $"0b{result.Substring( nibbleSplit.Length )}";
		}

		// Provides a mechanism for easily checking the state of specific bits in integer values.
		public static bool BitMaskMatch( this ulong source, ulong mask ) => (source & mask) == mask;

		public static bool BitMaskMatch( this long source, long mask ) => (source & mask) == mask;

		public static bool BitMaskMatch( this uint source, uint mask ) => (source & mask) == mask;

		public static bool BitMaskMatch( this int source, int mask ) => (source & mask) == mask;

		public static bool BitMaskMatch( this ushort source, ushort mask ) => (source & mask) == mask;

		public static bool BitMaskMatch( this short source, short mask ) => (source & mask) == mask;

		public static bool BitMaskMatch( this byte source, byte mask ) => (source & mask) == mask;

		public static bool BitMaskMatch( this sbyte source, sbyte mask ) => (source & mask) == mask;

		/// <summary>Returns the low order nibble of the source byte.</summary>
		public static byte Lo( this byte source ) => (byte)( source & 0x0f );

		/// <summary>Returns the high order nibble of the source byte.</summary>
		public static byte Hi( this byte source ) => (byte)((source & 0xf0) >> 4);

		/// <summary>Returns the low order byte of the source ushort value.</summary>
		public static byte Lo( this ushort source ) => (byte)(source & 0xff);

		/// <summary>Returns the high order byte of the source ushort value.</summary>
		public static byte Hi( this ushort source ) => (byte)((source & 0xff00) >> 8);

		/// <summary>Returns the low order word of the source uint value.</summary>
		public static ushort Lo( this uint source ) => (ushort)(source & 0x0000ffff);

		/// <summary>Returns the high order word of the source uint value.</summary>
		public static ushort Hi( this uint source ) => (ushort)((source & 0xffff0000) >> 16);

		/// <summary>Returns the low order double-word of the source ulong value.</summary>
		public static uint Lo( this ulong source ) => (uint)(source & 0x00000000ffffffff);

		/// <summary>Returns the high order double-word of the source ulong value.</summary>
		public static uint Hi( this ulong source ) => (uint)((source & 0xffffffff00000000) >> 32);

		public static byte Lo( this sbyte source ) => (byte)(source & 0x0f);

		public static byte Hi( this sbyte source ) => (byte)((source & 0xf0) >> 4);

		public static byte Lo( this short source ) => (byte)(source & 0xff);

		public static byte Hi( this short source ) => (byte)((source & 0xff00) >> 8);

		public static ushort Lo( this int source ) => (ushort)(source & 0x0000ffff);

		public static ushort Hi( this int source ) => (ushort)((source & 0xffff0000) >> 16);

		public static uint Lo( this long source ) => (uint)(source & 0x00000000ffffffff);

		public static uint Hi( this long source ) => (uint)(((ulong)source & 0xffffffff00000000) >> 32);
		#endregion
	}
}