﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace NetXpertExtensions
{
//#nullable enable

	/// <summary>Functions as an improved <seealso cref="List{string}"/> variant.</summary>
	/// <remarks>
	/// Adds functionality to emulate a <seealso cref="Queue"/> or <seealso cref="Stack"/>, and 
	/// to search/extract elements via <seealso cref="Regex"/></remarks>
	public class StringCollection : IEnumerator<string>, IEnumerable<string>, IEnumerable
	{
		#region Properties
		public readonly List<string> _lines = new();
		private int _position = 0;
		private bool disposedValue;
		private const DuplicateMode DEFAULT_DUPLICATE_MODE = DuplicateMode.Off;
		private bool _isSorted = false;
		private IComparer<string> _defaultComparer = CreateComparer( StringComparison.OrdinalIgnoreCase );

		/// <summary>Specifies what kinds of duplicate entries to disallow into the collection.</summary>
		public enum DuplicateMode { CurrentCulture, CurrentCultureIgnore, InvariantCulture, InvariantCultureIgnore, OrdinalIgnore, Ordinal, Off };
		#endregion

		#region Constructors
		public StringCollection( DuplicateMode disallowDuplicates = DEFAULT_DUPLICATE_MODE, bool allowEmptyEntries = false )
		{
			this.DisallowDuplicates = disallowDuplicates;
			this.AllowEmptyEntries = allowEmptyEntries;
		}

		public StringCollection( string line, DuplicateMode disallowDuplicates = DEFAULT_DUPLICATE_MODE, bool allowEmptyEntries = false )
		{ 
			this.DisallowDuplicates = disallowDuplicates;
			this.AllowEmptyEntries = allowEmptyEntries;
			this.Add( line );
		}

		public StringCollection( object item, DuplicateMode disallowDuplicates = DEFAULT_DUPLICATE_MODE, bool allowEmptyEntries = false )
		{
			this.DisallowDuplicates = disallowDuplicates;
			this.AllowEmptyEntries = allowEmptyEntries;
			this.Add( item );
		}

		public StringCollection( IEnumerable<string> lines, DuplicateMode disallowDuplicates = DEFAULT_DUPLICATE_MODE, bool allowEmptyEntries = false )
		{
			this.DisallowDuplicates = disallowDuplicates;
			this.AllowEmptyEntries = allowEmptyEntries;
			this.AddRange( lines );
		}

		public StringCollection( string source, char[] splitChars, StringSplitOptions options, DuplicateMode disallowDuplicates = DEFAULT_DUPLICATE_MODE, bool allowEmptyEntries = false )
		{
			this.DisallowDuplicates = disallowDuplicates;
			this.AllowEmptyEntries = allowEmptyEntries;
			this.AddRange( source.Split( splitChars, options ) );
		}
		#endregion

		#region Operators
		public static StringCollection operator +(StringCollection? a, string b)
		{
			if ( a is null ) return new StringCollection( b );
			if (string.IsNullOrEmpty(b)) return a;
			a.Add( b );
			return a;
		}

		public static StringCollection operator +(StringCollection? a, StringCollection? b)
		{
			if ( a is null ) return b; // a 'Null' return value is valid/acceptable!
			if ( b is null ) return a;
			a.Add( b );
			return a;
		}

		public static implicit operator StringCollection( string s ) => new( s );
		public static implicit operator StringCollection( string[] s ) => new( s );
		public static implicit operator StringCollection( List<string> s ) => new( s.ToArray() );
		public static implicit operator List<string>( StringCollection s ) =>
			s is null ? new() : new( s.ToArray() );
		#endregion

		#region Accessors
		/// <summary>Facilitates directly setting or getting collection entries by index.</summary>
		/// <remarks>If <i>null</i> (or an empty string: &quot;&quot;) are assigned to an index by this method, it will be removed from the collection!</remarks>
		public string this[ int index ]
		{
			get => this._lines[ index ];
			set
			{
				if ( string.IsNullOrEmpty( value ) )
					this.RemoveAt( index );
				else
					this._lines[ index ] = value;
			}
		}

		/// <summary>Reports the number of items currently managed within the collection.</summary>
		public int Count => this._lines.Count;

		/// <summary>Specifies whether or not the collection will accept empty/null entries.</summary>
		public bool AllowEmptyEntries { get; set; } = false;

		/// <summary>Specifies whether or not the collection will accept duplicate entries.</summary>
		/// <remarks>If not set to <i>off</i>, this specifies which matching method will be used to detect if a duplication is <b>true</b>.</remarks>
		public DuplicateMode DisallowDuplicates { get; set; } = DEFAULT_DUPLICATE_MODE;

		/// <summary>Provides a local conversion mechanism between the various <see cref="DuplicateMode"/> flags and the
		/// relevant <seealso cref="StringComparison"/> value.</summary>
		private StringComparison CompareMode => ParseMode( DisallowDuplicates );

		public string Current => this._lines[this._position];

		object IEnumerator.Current => Current;

		/// <summary>Determines whether or not the collection is sorted by default.</summary>
		/// <remarks>If this is activated, the object will use the value of <see cref="DefaultComparer"/> for performing internal sort operations.</remarks>
		public bool IsSortedCollection
		{
			get => this._isSorted;
			set
			{
				if ( value != this._isSorted )
				{
					if (value)
					{
						this._lines.Sort( DefaultComparer );
					}
				}
			}
		}

		/// <summary>This is the comparer that's used for all internal sorting/searching functions if one isn't provided.</summary>
		public IComparer<string> DefaultComparer 
		{ 
			get => this._defaultComparer;
			set { if ( value is not null ) { this._defaultComparer = value; } }
		} 
		#endregion

		#region Methods
		/// <summary>Facilitates comparing two strings under the auspices of the <see cref="AllowDuplicates"/> setting.</summary>
		private bool StringEquals( string s1, string s2 ) =>
			DisallowDuplicates == DuplicateMode.Off ? s1 == s2 : s1.Equals( s2, (StringComparison)DisallowDuplicates );

		/// <summary>Searches the collection for the first string to match the supplied <i>item</i>.</summary>
		/// <param name="item">A string to search for.</param>
		/// <returns>-1 if no match is found, otherwise the index of the <i>first</i> matching string.</returns>
		/// <remarks>Matches are ascertained by using the defined <see cref="AllowDuplicates"/> method.</remarks>
		public int IndexOf( string item )
		{
			if ( this._isSorted )
			{
				int index = this._lines.BinarySearch( item );
				return index < 0 ? -1 : index;
			}
			else
			{
				int i = -1; while ( (++i < Count) && !StringEquals( this._lines[ i ], item ) ) ;
				return (i < Count) ? i : -1;
			}
		}

		/// <summary>Searches the collection for the first string to match the supplied <i>item</i>.</summary>
		/// <returns>-1 if no match is found, otherwise the index of the <i>first</i> matching string.</returns>
		public int IndexOf( string item, StringComparison compare )
		{
			int i = -1; while ( (++i < Count) && !item.Equals( this._lines[ i ], compare ) ) ;
			return (i < Count) ? i : -1;
		}

		/// <summary>Searches the collection for the first string to match the supplied <seealso cref="Regex"/> pattern.</summary>
		/// <returns>-1 if no match is found, otherwise the index of the <i>first</i> matching string.</returns>
		/// <remarks>Note that the use of a <seealso cref="Regex"/> pattern necessarily obviates the <see cref="AllowDuplicates"/> comparator!</remarks>
		public int IndexOf( Regex match )
		{
			int i = -1; while ( (++i < Count) && !match.IsMatch( this._lines[ i ] ) ) ;
			return (i < Count) ? i : -1;
		}

		/// <summary>Adds a new string to the collection.</summary>
		/// <param name="item">The string to be added to the collection.</param>
		public void Add( string item )
		{
			if ( AllowEmptyEntries || !string.IsNullOrEmpty( item ) )
			{
				if ( (DisallowDuplicates == DuplicateMode.Off) || (IndexOf( item ) < 0) )
				{
					if (this._isSorted)
					{
						int i = this._lines.BinarySearch( item );
						if ( i < 0 ) this._lines.Insert( ~i, item );
					}
					else
						this._lines.Add( item );
				}
			}
		}

		/// <summary>Add the <i>ToString()</i> representation of a non-string object to the collection.</summary>
		/// <remarks>
		/// If the supplied object is derived from either <i>IEnumerable</i> or <i>IEnumerator</i>, each element
		/// will be added to the collection separately. Otherwise the string version of the supplied object will
		/// be used instead.
		/// </remarks>
		public void Add( object? s )
		{
			if (s is null) { this.Add( "" ); return; }

			// This can happen if the calling function happens to pass a string as an object.
			// Examples of how than can happen are in the 'AddRange' methods below.
			if ( s.IsDerivedFrom<string>() ) { this.Add((string)s); return; }

			// These checks have to be done in this order as all
			// IEnumerable objects also derive from IEnumerator...

			if ( s is IEnumerable )
			{
				this.AddRange( (IEnumerable)s );
				return;
			}

			if ( s is IEnumerator )
			{
				this.AddRange( (IEnumerator)s );
				return;
			}

			this.Add( s.ToString() );
		}

		/// <summary>Adds all elements from a supplied collection of strings to this collection.</summary>
		/// <param name="newLines">An <seealso cref="IEnumerable{string}"/> collection whose contents will be added (typically a string array).</param>
		public void AddRange( IEnumerable<string>? newLines )
		{
			if ( newLines is not null && (newLines.Count() > 0) )
				foreach ( string s in newLines )
					this.Add( s );
		}

		/// <summary>Adds all elements from the supplied collection to this one.</summary>
		/// <param name="objects">An <seealso cref="IEnumerable"/> object whose elements are to be added.</param>
		/// <param name="recursive">
		/// If set to <b>TRUE</b> and any of the child objects in <see cref="object"/> are derived from 
		/// <seealso cref="IEnumerable"/> or <see cref="IEnumerator"/>, they will be recursively parsed 
		/// and imported accordingly. Otherwise <i><see cref="object"/>.ToString()</i> will be used instead.
		/// </param>
		public void AddRange( IEnumerable objects, bool recursive = true )
		{
			if ( objects is not null )
				foreach ( var item in objects ) 
					this.Add( recursive ? item : item.ToString() ); ;
		}

		/// <summary>Adds all elements from the supplied collection to this one.</summary>
		/// <param name="objects">An <seealso cref="IEnumerator"/> object whose elements are to be added.</param>
		/// <param name="recursive">
		/// If set to <b>TRUE</b> and any of the child objects in <see cref="object"/> are derived from 
		/// <seealso cref="IEnumerable"/> or <see cref="IEnumerator"/>, they will be recursively parsed 
		/// and imported accordingly. Otherwise <i><see cref="object"/>.ToString()</i> will be used instead.
		/// </param>
		public void AddRange( IEnumerator objects, bool recursive = false )
		{
			if (objects is not null)
				while ( objects.MoveNext() ) 
					this.Add( recursive ? objects.Current : objects.Current.ToString() );
		}

		/// <summary>Returns the contents of the collection as an array of strings.</summary>
		public string[] ToArray() => this._lines.ToArray();

		/// <summary>Reports on whether the specified string exists in the collection.</summary>
		/// <remarks>The compared string looks for a FULL match. For partial matches use <seealso cref="Regex"/> via <seealso cref="Contains(Regex)"/> instead.</remarks>
		/// <param name="item">A string to search for.</param>
		/// <param name="caseSensitive">Whether or not the search differentiates by case.</param>
		/// <returns><b>TRUE</b> if a string was found in the collection that matches the one supplied, otherwise <b>FALSE</b>.</returns>
		public bool Contains( string item, StringComparison compare = StringComparison.OrdinalIgnoreCase ) =>
			IndexOf( item, compare ) >= 0;

		/// <summary>Reports on whether any strings in the collection match the supplied <seealso cref="Regex"/>.</summary>
		/// <param name="match">A <seealso cref="Regex"/> object that defines the match being sought.</param>
		/// <returns><b>TRUE</b> if a string was found in the collection that matches the supplied Regex, otherwise <b>FALSE</b>.</returns>
		public bool Contains( Regex match ) => IndexOf( match ) >= 0;

		/// <summary>Reports on whether any strings in the collection match the supplied <seealso cref="Regex"/> pattern + options.</summary>
		/// <returns><b>TRUE</b> if a string was found in the collection that matches the supplied <seealso cref="Regex"/> pattern, otherwise <b>FALSE</b>.</returns>
		public bool Contains( string pattern, RegexOptions options ) =>
			IndexOf( new Regex( pattern, options ) ) >= 0;

		/// <summary>Searches the collection for all strings that match the supplied <seealso cref="Regex"/> and returns them in a new <seealso cref='StringCollection'/> object.</summary>
		/// <param name="regex">A <seealso cref="Regex"/> object that defines the matches being sought.</param>
		/// <param name="allowDuplicates">If set to <b>TRUE</b> the new collection will accept duplicate entries.</param>
		/// <param name="allowEmptyEntries">If set to <b>TRUE</b> the new collection will accept empty entries.</param>
		/// <returns>A new <seealso cref='StringCollection'/> object containing all discovered matches.</returns>
		public StringCollection Matches( Regex regex, DuplicateMode allowDuplicates, bool allowEmptyEntries )
		{
			StringCollection result = new(allowDuplicates, allowEmptyEntries);
			foreach ( string s in _lines )
				if ( regex.IsMatch( s ) ) result += s;

			return result;
		}

		/// <summary>Searches the collection for all strings that match the supplied <seealso cref="Regex"/> and returns them in a new <seealso cref='StringCollection'/> object.</summary>
		/// <param name="regex">A <seealso cref="Regex"/> object that defines the matches being sought.</param>
		/// <returns>A new <seealso cref='StringCollection'/> object containing all discovered matches.</returns>
		/// <remarks>The generated collection's <see cref="AllowEmptyEntries"/> and <see cref="AllowDuplicates"/> values will match those of the source.</remarks>
		public StringCollection Matches( Regex regex ) => Matches( regex, this.DisallowDuplicates, this.AllowEmptyEntries );

		/// <summary>
		/// Searches the collection for all strings that match the supplied <seealso cref="Regex"/>, returns 
		/// them (in a new <seealso cref='StringCollection'/> object), <i>and <b><u>removes</u></b> them</i> from the source.
		/// </summary>
		/// <param name="regex">A <seealso cref="Regex"/> object that defines the matches being sought.</param>
		/// <returns>A new <seealso cref='StringCollection'/> object containing the extracted matches.</returns>
		public StringCollection ExtractMatches( Regex regex, DuplicateMode allowDuplicates, bool allowEmptyEntries ) 
		{
			StringCollection result = new( allowDuplicates, allowEmptyEntries );
			for ( int i = 0; i < Count; i++ )
				if ( regex.IsMatch( this[ i ] ) )
					result += this.RemoveAt( i-- ); // "--" is to decrement the counter!

			return result;
		}

		/// <summary>
		/// Searches the collection for all strings that match the supplied <seealso cref="Regex"/>, returns 
		/// them (in a new <seealso cref='StringCollection'/> object), <i>and <b><u>removes</u></b> them</i> from the source.
		/// </summary>
		/// <param name="regex">A <seealso cref="Regex"/> object that defines the matches being sought.</param>
		/// <returns>A new <seealso cref='StringCollection'/> object containing the extracted matches.</returns>
		public StringCollection ExtractMatches( Regex regex ) =>
			ExtractMatches( regex, this.DisallowDuplicates, this.AllowEmptyEntries );

		/// <summary>Searches the collection for all strings that match the supplied <seealso cref="Regex"/> pattern and returns them in a new <seealso cref='StringCollection'/> object.</summary>
		/// <param name="pattern">A string containing the regex pattern to use for matching.</param>
		/// <param name="options">A <i>RegexOptions</i> value modifying the way the match is compared.</param>
		/// <returns>A new <seealso cref='StringCollection'/> object containing all discovered matches.</returns>
		/// <remarks>The generated collection's <see cref="AllowEmptyEntries"/> value will be the same as the source's.</remarks>
		public StringCollection Matches( string pattern, RegexOptions options ) =>
			this.Matches( new Regex(pattern, options) );

		/// <summary>Searches the collection for all strings that match the supplied <seealso cref="Regex"/> pattern and returns them in a new <seealso cref='StringCollection'/> object.</summary>
		/// <param name="pattern">A string containing the regex pattern to use for matching.</param>
		/// <param name="options">A <i>RegexOptions</i> value modifying the way the match is compared.</param>
		/// <param name="allowEmptyEntries">If set to <b>TRUE</b> the new collection will accept empty entries.</param>
		/// <returns>A new <seealso cref='StringCollection'/> object containing all discovered matches.</returns>
		public StringCollection Matches( string pattern, RegexOptions options, DuplicateMode allowDuplicates, bool allowEmptyEntries ) =>
			this.Matches( new Regex( pattern, options ), allowDuplicates, allowEmptyEntries );

		/// <summary>Returns the contents of the collection as a single line with entries separated by a space.</summary>
		public override string ToString() => this.ToString( " " ); // "\r\n• "

		/// <summary>Returns the contents of the collection as a comma-separated-values string (with values enclosed in quotes).</summary>
		/// <param name="useTab">If <b>TRUE</b>, TABs (ASCII:0x09) are used instead of commas.</param>
		public string ToCSV( bool useTab = false ) =>
			$"\x22{this.ToString(useTab?"\x22\x09\x22":"\x22,\x22")}\x22";

		/// <summary>Returns the contents of the collection as a single string.</summary>
		/// <remarks>Individual items are combined using the string provided in <i>glue</i>.</remarks>
		/// <param name="glue">A string specifying the character(s) that will bind the strings together.</param>
		public string ToString( string glue ) =>
			this.Count switch
			{
				0 => "",
				1 => this._lines[ 0 ],
				_ => string.Join( glue, this._lines )
			};

		/// <summary>Removes the item from the collection at the specified index and returns it to the caller.</summary>
		/// <param name="index">The location within the collection that is to be removed.</param>
		/// <returns>The value that was removed from the collection.</returns>
		public string RemoveAt( int index )
		{
			string r = this[ index ];
			this._lines.RemoveAt( index );
			return r;
		}

		// I genuinely have no idea what this would be used for, but is put here for completeness..
		/// <summary>Searches for a matching string within the collection and removes it, if found.</summary>
		/// <param name="item">A string to seek and remove from the collection.</param>
		/// <param name="compare">A <seealso cref="StringComparison"/> value to govern the mechanism of matching.</param>
		/// <returns>The removed string if found, otherwise an empty string.</returns>
		public string Remove( string item, StringComparison compare = StringComparison.CurrentCulture )
		{
			string result = "";
			int i = IndexOf( item, compare );
			if ( i >= 0 )
			{
				result = this[ i ];
				this._lines.RemoveAt( i );
			}
			return result;
		}

		/// <summary>Reports <b>TRUE</b> if there are any elements in the collection, otherwise <b>FALSE</b>.</summary>
		public bool Any() => this._lines.Any();

		#region Sorting methods.
		public void Sort() => this._lines.Sort(DefaultComparer);

		public void Sort( IComparer<string>? iComparer )
		{
			if ( this._isSorted ) throw new InvalidOperationException( $"You cannot apply a manual sort to a self-sorting list." );
			this._lines.Sort( iComparer );
		}

		public void Sort( Comparison<string> comparison )
		{
			if ( this._isSorted ) throw new InvalidOperationException( $"You cannot use a manual sort on a self-sorted list." );
			this._lines.Sort( comparison );
		}
		#endregion

		/// <summary>Clears all entries in the collection.</summary>
		public void Clear() => this._lines.Clear();

		/// <summary>(LIFO): Returns the last item from the collection (<i>and <b><u>removes</u></b> it!</i>)</summary>
		/// <remarks>The <seealso cref="Add(string)"/> function will serve for a <i>Push</i></remarks>
		public string Pop() => Count > 0 ? this.RemoveAt( Count - 1 ) : String.Empty;

		/// <summary>(FIFO): Returns the first item in the collection (<i>and <b><u>removes</u></b> it!</i>)</summary>
		/// <remarks>The <seealso cref="Add(string)"/> function will serve for <i>Enqueue</i></remarks>
		public string Dequeue() => Count > 0 ? this.RemoveAt(0) : String.Empty;

		/// <summary>Injects a new string into the collection at the specified point.</summary>
		public void Insert( string item, int where = 0 )
		{
			if ( this._isSorted ) throw new InvalidOperationException( $"You cannot insert a value at a set location in a self-sorted list." );
			this._lines.Insert( where, item );
		}

		/// <summary>Injects the string representation of the supplied object into the collection.</summary>
		public void Insert( object item, int where = 0 )
		{
			if ( this._isSorted ) throw new InvalidOperationException( $"You cannot insert a value at a set location in a self-sorted list." );
			this._lines.Insert( where, item is null ? "" : item.ToString() );
		}

		public bool MoveNext() => ++this._position < this._lines.Count();

		public void Reset() => this._position = 0;

		public static StringComparison ParseMode( DuplicateMode value ) =>
				(int) value switch
				{
					0 => StringComparison.Ordinal,
					1 => StringComparison.CurrentCulture,
					3 => StringComparison.CurrentCultureIgnoreCase,
					> 5 => StringComparison.InvariantCultureIgnoreCase,
					> 3 => StringComparison.InvariantCulture,
					_ => StringComparison.OrdinalIgnoreCase
				};

		public static IComparer<string> CreateComparer( StringComparison comparison ) => new MyStringComparer( comparison );

		private class MyStringComparer : IComparer<string>
		{
			#region Properties
			private readonly StringComparison _comparison = StringComparison.CurrentCultureIgnoreCase;
			#endregion

			#region Constructor
			public MyStringComparer( StringComparison stringComparison = StringComparison.CurrentCultureIgnoreCase ) =>
				this._comparison = stringComparison;
			#endregion

			#region Methods
			public int Compare(string left, string right )
			{
				if ((left is null) || (right is null))
					throw new ArgumentNullException( left is null ? nameof(left) : nameof(right) );

				return string.Compare( left, right, _comparison );
			}
			#endregion
		}

		#region IDisposable Support
		private void Dispose( bool disposing )
		{
			if ( !disposedValue )
			{
				if ( disposing )
				{
					// TODO: dispose managed state (managed objects)
				}

				// TODO: free unmanaged resources (unmanaged objects) and override finalizer
				// TODO: set large fields to null
				disposedValue = true;
			}
		}

		// // TODO: override finalizer only if 'Dispose(bool disposing)' has code to free unmanaged resources
		// ~StringCollection()
		// {
		//     // Do not change this code. Put cleanup code in 'Dispose(bool disposing)' method
		//     Dispose(disposing: false);
		// }

		public void Dispose()
		{
			// Do not change this code. Put cleanup code in 'Dispose(bool disposing)' method
			Dispose( disposing: true );
			GC.SuppressFinalize( this );
		}

		public IEnumerator GetEnumerator()
		{
			return ((IEnumerable)this._lines).GetEnumerator();
		}

		IEnumerator<string> IEnumerable<string>.GetEnumerator()
		{
			return ((IEnumerable<string>)this._lines).GetEnumerator();
		}
		#endregion
		#endregion
	}
}
